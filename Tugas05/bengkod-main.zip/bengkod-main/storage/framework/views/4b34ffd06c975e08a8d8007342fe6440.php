<?php $__env->startSection('title', 'Tambah Permintaan Periksa'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Permintaan Periksa Baru</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('pasien.periksa.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="id_dokter">Pilih Dokter</label>
                    <select name="id_dokter" id="id_dokter" class="form-control" required>
                        <?php $__currentLoopData = $dokters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dokter->id); ?>"><?php echo e($dokter->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="tgl_periksa">Tanggal Periksa</label>
                    <input type="datetime-local" name="tgl_periksa" id="tgl_periksa" class="form-control" required>
                </div>

                <div class="d-flex justify-content-end" style="gap:10px;">
                    <button type="submit" class="btn btn-success">Ajukan</button>
                    <a href="<?php echo e(route('periksa.pasienindex')); ?>" class="btn btn-secondary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\teguh\Downloads\bengkod-main\bengkod-main\resources\views/pasien/periksa/create.blade.php ENDPATH**/ ?>