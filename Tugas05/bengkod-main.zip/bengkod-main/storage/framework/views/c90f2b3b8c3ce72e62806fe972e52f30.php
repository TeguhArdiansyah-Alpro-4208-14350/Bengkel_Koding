<?php $__env->startSection('subtitle', 'Periksa'); ?>
<?php $__env->startSection('content_header_title', 'Data Periksa'); ?>
<?php $__env->startSection('content_body'); ?>
    <div class="card">
        
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Pasien</th>
                        <th>Dokter</th>
                        <th>Tanggal Periksa</th>
                        <th>Catatan</th>
                        <th>Biaya</th>
                        <th>Obat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $periksas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periksa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($periksa->pasien->name ?? '-'); ?></td>
                            <td><?php echo e($periksa->dokter->name ?? '-'); ?></td>
                            <td><?php echo e($periksa->tgl_periksa); ?></td>
                            <td><?php echo e($periksa->catatan); ?></td>
                            <td>Rp<?php echo e(number_format($periksa->biaya_periksa, 0, ',', '.')); ?></td>
                            <td>
    <?php if($periksa->obats->count()): ?>
        <ul class="mb-0 ps-3">
            <?php $__currentLoopData = $periksa->obats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($obat->nama_obat); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <span>-</span>
    <?php endif; ?>
</td>
                            <td>
                                <a href="<?php echo e(route('periksa.edit', $periksa->id)); ?>" class="btn btn-warning">periksa</a>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\teguh\Downloads\bengkod-main\bengkod-main\resources\views/dokter/periksa/index.blade.php ENDPATH**/ ?>