<footer class="main-footer">
    <?php echo $__env->yieldContent('footer'); ?>
</footer><?php /**PATH C:\Users\teguh\Downloads\bengkod-main\bengkod-main\resources\views/vendor/adminlte/partials/footer/footer.blade.php ENDPATH**/ ?>