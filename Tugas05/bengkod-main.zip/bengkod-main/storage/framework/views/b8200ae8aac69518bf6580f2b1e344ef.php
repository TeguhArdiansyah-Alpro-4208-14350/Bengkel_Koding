<?php $__env->startSection('title', 'Edit Pemeriksaan'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="card-header">
        <a href="<?php echo e(route('periksa.index')); ?>" class="btn btn-primary">Kembali ke Daftar Pemeriksaan</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('periksa.update', $periksa->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Form untuk Pasien -->
                <div class="form-group">
                    <label for="id_pasien">Pasien</label>
                    <select name="id_pasien" class="form-control" required>
                        <?php $__currentLoopData = $pasiens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pasien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pasien->id); ?>" 
                                <?php echo e($pasien->id == $periksa->id_pasien ? 'selected' : ''); ?>>
                                <?php echo e($pasien->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Form untuk Dokter -->
                <div class="form-group">
                    <label for="id_dokter">Dokter</label>
                    <select name="id_dokter" class="form-control" required>
                        <?php $__currentLoopData = $dokters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dokter->id); ?>" 
                                <?php echo e($dokter->id == $periksa->id_dokter ? 'selected' : ''); ?>>
                                <?php echo e($dokter->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Form untuk Tanggal Pemeriksaan -->
                <div class="form-group">
                    <label for="tgl_periksa">Tanggal Periksa</label>
                    <input type="datetime-local" name="tgl_periksa" value="<?php echo e($periksa->tgl_periksa); ?>" class="form-control" required>
                </div>

                <!-- Form untuk Catatan -->
                <div class="form-group">
                    <label for="catatan">Catatan</label>
                    <textarea name="catatan" class="form-control"><?php echo e($periksa->catatan); ?></textarea>
                </div>

                <!-- Form untuk Biaya Pemeriksaan -->
                <div class="form-group">
                    <label for="biaya_periksa">Biaya Pemeriksaan</label>
                    <input type="number" name="biaya_periksa" value="<?php echo e($periksa->biaya_periksa); ?>" class="form-control">
                </div>

                <!-- Form untuk Obat -->
                <div class="form-group">
                    <label for="obat_ids">Obat (bisa pilih lebih dari satu)</label>
                    <select name="obat_ids[]" class="form-control" multiple>
                        <?php $__currentLoopData = $obats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($obat->id); ?>" 
                                <?php echo e(in_array($obat->id, $periksa->obats->pluck('id')->toArray()) ? 'selected' : ''); ?>>
                                <?php echo e($obat->nama_obat); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Tombol submit dan kembali -->
                <div class="wrapper d-flex justify-content-end" style="gap: 10px;">
                    <button type="submit" class="btn btn-success">Ubah</button>
                    <a href="<?php echo e(route('periksa.index')); ?>" class="btn btn-secondary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\teguh\Downloads\bengkod-main\bengkod-main\resources\views/dokter/periksa/edit.blade.php ENDPATH**/ ?>