```blade


<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4 text-center">Daftar Rumah Sakit</h2>
    
    <a href="<?php echo e(route('rumah_sakit.create')); ?>" class="btn btn-primary mb-3">Tambah Rumah Sakit</a>

    <div class="table-responsive">
        <table class="table table-striped table-bordered text-center">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Telepon</th>
                    <th>Kapasitas</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $rumahSakits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rs->id); ?></td>
                    <td><?php echo e($rs->nama); ?></td>
                    <td><?php echo e($rs->alamat); ?></td>
                    <td><?php echo e($rs->telepon); ?></td>
                    <td><?php echo e($rs->kapasitas); ?></td>
                    <td>
                        <a href="<?php echo e(route('rumah_sakit.edit', $rs->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('rumah_sakit.destroy', $rs->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
```

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampppp\htdocs\bengkel_koding\resources\views/rumah_sakit/index.blade.php ENDPATH**/ ?>