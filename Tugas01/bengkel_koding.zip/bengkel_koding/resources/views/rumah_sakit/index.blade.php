```blade
@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <h2 class="mb-4 text-center">Daftar Rumah Sakit</h2>
    
    <a href="{{ route('rumah_sakit.create') }}" class="btn btn-primary mb-3">Tambah Rumah Sakit</a>

    <div class="table-responsive">
        <table class="table table-striped table-bordered text-center">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Telepon</th>
                    <th>Kapasitas</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($rumahSakits as $rs)
                <tr>
                    <td>{{ $rs->id }}</td>
                    <td>{{ $rs->nama }}</td>
                    <td>{{ $rs->alamat }}</td>
                    <td>{{ $rs->telepon }}</td>
                    <td>{{ $rs->kapasitas }}</td>
                    <td>
                        <a href="{{ route('rumah_sakit.edit', $rs->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('rumah_sakit.destroy', $rs->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
```
