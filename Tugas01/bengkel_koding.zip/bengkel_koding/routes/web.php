<?php

use App\Http\Controllers\RumahSakitController;
Route::resource('rumah_sakit', RumahSakitController::class);
