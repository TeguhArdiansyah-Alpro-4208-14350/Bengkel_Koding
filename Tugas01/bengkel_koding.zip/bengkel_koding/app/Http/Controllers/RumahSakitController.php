<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\RumahSakit;

class RumahSakitController extends Controller
{
    public function index()
    {
        $rumahSakits = RumahSakit::all();
        return view('rumah_sakit.index', compact('rumahSakits'));
    }

    public function create()
    {
        return view('rumah_sakit.create');
    }

    public function store(Request $request)
    {
        RumahSakit::create($request->all());
        return redirect()->route('rumah_sakit.index');
    }

    public function edit($id)
    {
        $rumahSakit = RumahSakit::findOrFail($id);
        return view('rumah_sakit.edit', compact('rumahSakit'));
    }

    public function update(Request $request, $id)
    {
        $rumahSakit = RumahSakit::findOrFail($id);
        $rumahSakit->update($request->all());
        return redirect()->route('rumah_sakit.index');
    }

    public function destroy($id)
    {
        RumahSakit::destroy($id);
        return redirect()->route('rumah_sakit.index');
    }
}
