

<?php $__env->startSection('subtitle', 'Periksa'); ?>
<?php $__env->startSection('content_header_title', 'Data Periksa'); ?>
<?php $__env->startSection('content_body'); ?>
    <div class="card">
        <div class="card-header">
            <a href="<?php echo e(route('periksa.create')); ?>" class="btn btn-primary">Tambah Periksa</a>
        </div>
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Pasien</th>
                        <th>Dokter</th>
                        <th>Tanggal Periksa</th>
                        <th>Catatan</th>
                        <th>Biaya</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $periksas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periksa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($periksa->pasien->name ?? '-'); ?></td>
                            <td><?php echo e($periksa->dokter->name ?? '-'); ?></td>
                            <td><?php echo e($periksa->tgl_periksa); ?></td>
                            <td><?php echo e($periksa->catatan); ?></td>
                            <td>Rp<?php echo e(number_format($periksa->biaya_periksa, 0, ',', '.')); ?></td>
                            <td>
                                <a href="<?php echo e(route('periksa.edit', $periksa->id)); ?>" class="btn btn-warning">Edit</a>
                                <form action="<?php echo e(route('periksa.destroy', $periksa->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\syifabengkod\resources\views/dokter/periksa/index.blade.php ENDPATH**/ ?>