

<?php $__env->startSection('subtitle', 'Dokter'); ?>
<?php $__env->startSection('content_header_title', 'Obat'); ?>
<?php $__env->startSection('content_body'); ?>
    <div class="card">
        <div class="card-header">
            <a href="<?php echo e(route('obat.create')); ?>" class="btn btn-primary">Tambah Obat</a>
        </div>
        <div class="card-body">
            <table class="table tbale-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Obat</th>
                        <th>Kemasan</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $obats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($obat->id); ?></td>
                            <td><?php echo e($obat->nama_obat); ?></td>
                            <td><?php echo e($obat->kemasan); ?></td>
                            <td><?php echo e($obat->harga); ?></td>

                            <td>
                                <a href="<?php echo e(route('obat.edit', $obat->id)); ?>" class="btn btn-warning">Edit</a>
                                <form action="<?php echo e(route('obat.destroy', $obat->id)); ?>" method="POST"
                                    style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\syifabengkod\resources\views/dokter/obat/index.blade.php ENDPATH**/ ?>